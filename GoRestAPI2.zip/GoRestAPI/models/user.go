package models

type UserRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

type User struct {
	Email    string `json:"email"`
	Password string `json:"password"`
	Hash     string `json:"hash"`
	Id       int    `json:"id"`
	Active   int    `json:"active"`
}
