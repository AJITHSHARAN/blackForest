package models

//Exception struct declaration
type Exception struct {
	Message string `json:"message"`
}
